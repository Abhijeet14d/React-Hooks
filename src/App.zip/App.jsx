import { BrowserRouter as Router, Route, Routes, Link, useNavigate } from 'react-router-dom';
import Home from './component/Home';
import Blog from './component/Blog';
import About from './component/About';
import Post from './component/Post';

function Navigation() {
  const navigate = useNavigate();

  return (
    <div>
      <nav>
        <Link to="/">Home</Link>
        <Link to="/blog">Blog</Link>
        <Link to="/about">About</Link>
      </nav>
      <button onClick={() => navigate(-1)}>Go Back</button>
      <button onClick={() => navigate(1)}>Go Forward</button>
    </div>
  );
}

function App() {
  return (
    <Router>
      <Navigation />
      <Routes>
        <Route exact path="/" element={<Home />} />
        <Route exact path="/blog" element={<Blog />} />
        <Route path="/about" element={<About />} />
        <Route path="/blog/:id" element={<Post />} />
      </Routes>
    </Router>
  );
}

export default App;